<?php 
namespace App\Controllers;
  
use CodeIgniter\Controller;
  
class Panel_controller extends Controller
{
    public function index()
    {

        $session = session(); //Sesion iniciada.
        $nombre=$session->get('usuario'); //Nombre del usuario que inicio sesion guardada como variable.
        $perfil=$session->get('perfil_id');//Id del usuario que inicio sesion guardada como variable.
        $data['perfil_id']=$perfil;    
        $data['nombre']=$nombre; 
        $dato["title"]="Panel del Usuario";
        echo view('front/head_view',$data);
        echo view('back/usuario/panel/panel');
        echo view ('back/login/login2',$data); //Conexion de la varialbe con el nombre y el id.
        echo view('front/footer_view');       
     }
}

