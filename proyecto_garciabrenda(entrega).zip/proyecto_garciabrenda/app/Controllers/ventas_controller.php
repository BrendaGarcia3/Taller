<?php
namespace App\Controllers;
use App\Models\producto_model;
use App\Models\ventas_cabecera_model;
use App\Models\ventas_detalle_model;
use App\Models\categoria_model;

class ventas_controller extends Basecontroller {

    private $cart;
    private $productos_modelo;
    private $venta_modelo;
    private $ventas_detalle_model;


    public function __construct() {
        $this->cart = \Config\Services::cart();
        $this->producto_model = new producto_model();
        $this->venta_modelo = new ventas_cabecera_model();
        $this->ventas_detalle_model = new ventas_detalle_model();
    }

    //registra la venta 
    public function registro_venta()  {

        $cartItems = $this->cart->contents();
        $venta_id = null;
        $total_venta = 0; // inicia en 0

        foreach ($cartItems as $item) {
            $productos = $this->producto_model->where('id', $item['id'])->first();
            if ($productos['stock'] < $item['qty']) {
                return redirect()->route('carrito');
            }


            // Guardar venta y obtener el ID solo una vez
            if (!$venta_id) {
                $data = [
                    'usuario_id' => session('id'),
                    'fecha' => date('Y-m-d H:i:s'),
                    'total_venta'   => 0
                ];
                $venta_id = $this->venta_modelo->insert($data);
            }

            $detalle_venta = [
                'venta_id'         => $venta_id,
                'producto_id'      => $item['id'],
                'cantidad' => $item['qty'],
                'precio'   => $item['price'],
            ];

            $nuevoStock = $productos['stock'] - $item['qty'];
            $this->producto_model->update($item['id'], ['stock' => $nuevoStock]);

            $this->ventas_detalle_model->insert($detalle_venta);

            // Calcular la suma del total de la venta
            $total_venta += ($item['price'] * $item['qty']);
        }

        // Actualizar el campo 'total_venta' en la tabla de ventas
        $this->venta_modelo->update($venta_id, ['total_venta' => $total_venta]);

        $this->cart->destroy();
        //return redirect()->route('principal');
        //return redirect()->to(base_url('compraRealizada') );

     //FACTURA
     $detalle_ventas = new ventas_detalle_model();
     $data['ventas_detalle'] = $detalle_ventas->getDetalles($venta_id);

     $productoModel = new producto_model();
     $data['productoModel'] = $productoModel;
     //------------------------------------------------------------------------
       
        $session = session();
            $cart = \Config\Services::cart();
            $cart = $cart->contents();

            $data['titulo'] = 'venta';
            echo view('front/head_view', $data);
            echo view('back/usuario/panel/panel');
            echo view('back/carrito/compraRealizada',$data);
            echo view('front/footer_view');
    }



}