<?php

namespace App\Controllers;
use App\Models\producto_model;

class Home extends BaseController
{
    
    public function index()    {
       
        $data['titulo'] = 'Inicio'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/principal'); 
        echo view('front/footer_view'); 
    }

    public function principal() {
        $model = new producto_model(); // Nombre correcto del modelo
        $data['productos'] = $model->obtenerNovedades(); // Obtener productos

        $data['titulo'] = 'principal'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/principal', $data); // Pasar $data a la vista
        echo view('front/footer_view'); 
    }

    public function SobreNosotros()    {
       
        $data['titulo'] = 'SobreNosotros'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/nosotros'); 
        echo view('front/footer_view'); 
    }

    public function comercializacion()    {
       
        $data['titulo'] = 'Comercializacion'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/comercializacion'); 
        echo view('front/footer_view'); 
    }

    public function terminosYusos()    {
       
        $data['titulo'] = 'TerminosyUsos'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/terminosYusos'); 
        echo view('front/footer_view'); 
    }

   
    public function perfumM()    {
       
        $data['titulo'] = 'PerfumeM'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/perfumM'); 
        echo view('front/footer_view'); 
    }

    public function perfumH()    {
       
        $data['titulo'] = 'PerfumeH'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/perfumH'); 
        echo view('front/footer_view'); 
    }

    public function perfumNinos()    {
       
        $data['titulo'] = 'PerfumeNinos'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/perfumNinos'); 
        echo view('front/footer_view'); 
    }
   //  el  nombre de la funcion debe ser igual al nombre que va en Routes - Home::
    public function perfumBebe()    {
       
        $data['titulo'] = 'PerfumeBebe'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/perfumBebe'); 
        echo view('front/footer_view'); 
    }

    public function contacto()    {
       
        $data['titulo'] = 'contacto'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('front/contacto'); 
        echo view('front/footer_view'); 
    }


    //Back-end

    public function registro()    {
       
        $data['titulo'] = 'registro'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('back/usuario/registro'); 
        echo view('front/footer_view'); 
    }
   
    public function login()    {
       
        $data['titulo'] = 'login'; 
        echo view('front/head_view', $data); 
        echo view('front/nav_view'); 
        echo view('back/login/login'); 
        echo view('front/footer_view'); 

    }

    public function catalogo2() {
        $data['titulo']='catalogo';
        echo view('front/head_view', $data); 
        echo view('back/usuario/panel/panel'); 
        echo view('back/carrito/catalogo2');
        echo view('front/footer_view'); 
    }

    

    
}



