<?php

namespace App\Controllers;

use App\Models\Usuarios_model;
use CodeIgniter\Session\Session;

class Usuario_controller extends BaseController
{

    public function __construct()
    {
        $this->session = \Config\Services::session();
    }

    // Muestra lista de usuarios
    public function index()
    {
        // Verificar si el usuario está logueado como admin
        if (!$this->isLoggedInAsAdmin()) {
            return redirect()->to('login')->with('error', 'Debes iniciar sesión como administrador');
        }

        $usuariosModel = new Usuarios_model();
        $data['users'] = $usuariosModel->orderBy('id', 'ASC')->findAll();
        $data['title'] = "Ver usuarios";
         echo view('front/head_view',$data);
        echo view('front/nav_view');
        echo view("back/usuario/usuario_view", $data);
        echo view('front/footer_view');   

    }
        // Mostrar un usuario individual
        public function singleUser($id = null)
        {
                // Verificar si el usuario está logueado
                // if (!$this->isLoggedIn()) {
                //     return redirect()->to('login')->with('error', 'Debes iniciar sesión');
                // }

                $userModel = new Usuarios_model();
                $data['user'] = $userModel->where('id', $id)->first();
                $data["title"] = "Editar un usuario";
                echo view('front/head_view',$data);
                echo view('front/nav_view');
                echo view("back/usuario/edit_usuario", $data);
                echo view('front/footer_view');   

        }

            // Actualizar los datos del usuario
            public function update()
            {
                
                $userModel = new Usuarios_model();
                $id = $this->request->getVar('id');
                $data = [
                    'nombre' => $this->request->getVar('nombre'),
                    'email' => $this->request->getVar('email'),
                    'usuario' => $this->request->getVar('usuario'),
                    'password' => $this->request->getVar('pass'),
                ];
                $userModel->update($id, $data);
                return $this->response->redirect(site_url('/crud_usuario'));
            }

            // Eliminar un usuario
            public function delete($id = null)
            {
                // Verificar si el usuario está logueado
                if (!$this->isLoggedIn()) {
                    return redirect()->to('login')->with('error', 'Debes iniciar sesión');
                }

                $userModel = new Usuarios_model();
                $data['user'] = $userModel->where('id', $id)->delete($id);
                return $this->response->redirect(site_url('/users-list'));
            }

            // Iniciar sesión de usuario
            public function login()
            {
                // Obtener los datos de inicio de sesión enviados por el usuario
                $username = $this->request->getPost('username');
                $password = $this->request->getPost('password');

                // Verificar las credenciales del usuario
                $usuarioModel = new Usuarios_model();
                $usuario = $usuarioModel->verificarCredenciales($username, $password);

                if ($usuario) {
                    // Guardar el ID del usuario en la sesión
                    $this->session->set('usuario_id', $usuario['id']);

                    // Redirigir a la página principal o a la página deseada
                    return redirect()->to('inicio');
                } else {
                    // Las credenciales no son válidas, mostrar mensaje de error
                    return redirect()->back()->with('error', 'Credenciales inválidas');
                }
            }

            // Cerrar sesión de usuario
            public function logout()
            {
                // Eliminar el ID del usuario de la sesión
                $this->session->remove('usuario_id');

                // Redirigir al formulario de inicio de sesión
                return redirect()->to('login')->with('success', 'Has cerrado sesión');
            }

            // Verificar si el usuario está logueado
            private function isLoggedIn()
            {
                return $this->session->has('usuario_id');
            }

            // Verificar si el usuario está logueado como admin
            protected function isLoggedInAsAdmin(): bool
            {
                return $this->session->has('usuario_id') && $this->isUserAdmin($this->session->get('usuario_id'));
            }

            // Verificar si el usuario es administrador
            private function isUserAdmin($usuario_id)
            {
                // Aquí debes implementar la lógica para determinar si el usuario es administrador o no
                // Puedes consultar la base de datos o utilizar alguna otra forma de verificación

                // Ejemplo de implementación:
                $userModel = new Usuarios_model();
                $user = $userModel->find($usuario_id);

                // Verificar si el usuario existe y tiene un campo "admin" igual a 1 (indicando que es admin)
                if ($user && $user['admin'] == 1) {
                    return true;
                }

                return false;
            }

//-----------------------------------------------------------------------------------------------------------
//           **   PERFIL **

            public function perfil() {
                $session = session();
        
                // Verificar si hay una sesión iniciada
                if (!$session->has('id')) {
                    return redirect()->to('/panel'); // Redirigir si no hay sesión
                }
        
                $usuarioModel = new Usuarios_model();
                $usuario = $usuarioModel->find($session->get('id'));
        
                // Verificar si el usuario existe
                if (!$usuario) {
                    return redirect()->to('/login'); // Redirigir si no se encuentra
                }
        
                // Pasar los datos a la vista
                return view('back/usuario/perfil', [
                    'nombre'  => $usuario['nombre'],
                    'email'  => $usuario['email'],
                    'usuario' => $usuario['usuario'],
                    'perfil_id'     => $usuario['perfil_id']
                ]);

            }




            public function perfil_index() {
                $usuariosModel = new Usuarios_model();
                
                // Obtener usuario autenticado (ajústalo según tu autenticación)
                $usuario = $usuariosModel->where('id', session()->get('id_usuario'))->first();
                
                if (!$usuario) {
                    return redirect()->to('/login'); // Redirigir si no hay usuario
                }
            
                // Pasar datos a las vistas
                $data = [
                    'title' => "Mi Perfil",
                    'nombre' => $usuario['nombre'],
                    'email' => $usuario['email'],
                    'usuario' => $usuario['usuario'],
                    'perfil_id' => $usuario['perfil_id'],
                ];
            
                echo view('front/head_view', $data);
                echo view('back/usuario/panel/panel', $data);
                echo view('back/usuario/perfil', $data);
                echo view('front/footer_view');  
            }
            

 }
        

 