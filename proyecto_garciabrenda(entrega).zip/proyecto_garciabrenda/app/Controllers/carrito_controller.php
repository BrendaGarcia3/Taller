<?php 
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\Usuarios_model;
use App\Models\producto_model;
Use App\Models\ventas_cabecera_model;
Use App\Models\ventas_detalle_model;

//namespace CodeIgniterCart;

class carrito_controller extends BaseController {

    public function __construct(){
        helper(['form', 'url','cart']);
        
        $session = session();
        $cart = \Config\Services::cart();
        $cart->contents();
    }   

 
    //MUESTRA EL CATALOGO
    public function catalogo2(){        
		
      $session=session();
     
      $dato = array('titulo' => 'Productos');
      $productoModel = new producto_model();
      $data['productos'] = $productoModel->orderBy('id', 'DESC')->findAll();


      echo view('front/head_view', $dato);
      echo view('back/usuario/panel/panel');
      echo view('back/carrito/catalogo2',$data);
      echo view('front/footer_view');
    }


    //MUESTRA EL CARRITO 
	  public function index() {      
    
     $session = session();
     $cart = \Config\Services::cart();
     $cart = $cart->contents();

		 /*$dato = array('titulo' => 'Productos');
		 $productoModel = new producto_model();
		 $data['productos'] = $productoModel->orderBy('id', 'DESC')->findAll(); */

     $data['titulo'] = 'carrito';
      echo view('front/head_view', $data);
      echo view('back/usuario/panel/panel');
      echo view('back/carrito/carrito',$data);
      echo view('front/footer_view');
	
	  }

    
    //AGREDA ITEMS AL CARRITO
    public function add() {                       //NO TIENE FUNCION AUN 

        $cart = \Config\Services::Cart();
        $request = \Config\Services::request();
      
        $cart->insert(array(
        'id'      =>  $request->getPost('id'),
        'qty'     =>  1,
        'name'    => $request->getPost('nombre_producto'),
        'price'   => $request->getPost('precio_venta'),
       
        ));
       
          return redirect()->to(base_url('catalogo2'));
          //return redirect()->back()->withInput();
    }
  

    public function remove($rowid) {            //NO FUNCIONA 
   
         $cart = \Config\Services::Cart();
         $request = \Config\Services::request();
      //Si $rowid es "all" destruye el carrito
        if ($rowid==="all")
        {
          $cart->destroy();
        }
        else //Sino destruye sola fila seleccionada
        { 
          $cart->remove($rowid);
        }
        // Redirige a la misma página que se encuentra
        
       // return redirect()->to(base_url('carrito'));
         return redirect()->back()->withInput();
   
    }
   
      
    //Actualiza el carrito que se muestra
     public function actualiza_carrito()  {        
        $cart = \Config\Services::Cart();
     
         $request = \Config\Services::request();
    
          $cart->update(array(
            'id'      => $request->getPost('id'),
            'qty'     =>  1,
            'name'    => $request->getPost('nombre_producto'),
            'price'   => $request->getPost('precio_venta'),   
   
          ));
        return redirect()->back()->withInput();
     }


      //---------------------------------------------------------------------------
       
       //devuelve el contenido actual del carrito de compras
      public function devolver_carrito(){
            $cart = \Config\Services::cart();
            return $cart->contents(); // devuelve el contenido actual del carrito, productos que se agregaron al carrito
      }

    //------------------------------------------------------------------------------

       
     public function borrar_carrito() {       
            $cart = \Config\Services::cart();
            $cart->destroy();

          return redirect()->to(base_url('Carrito'));

    }


      public function restar_carrito() {
            $cart = \Config\Services::cart();
            $productos = $cart->contents();
            $cantidad = $cart->getItem($this->request->getGet("id"))["qty"];
                    
                    if($cantidad > 1){ 
                        $cart->update(array(
                            "rowid" => $this->request->getGet("id"),
                            "qty" => $cantidad-1
                        ));
                    }
                    return redirect()->back()->withInput();
                  // return redirect()->route('panel_carrito');
        }

        //---------------------------------------------------------------------------
        public function sumar_carrito() {
                  $cart = \Config\Services::cart();

                  $cantidad = $cart->getItem($this->request->getGet("id"))["qty"];
                  $cantidadMax = $cart->getItem($this->request->getGet("id"))["stock"];
                  
                  if($cantidad < $cantidadMax){ 
                      $cart->update(array(
                          "rowid" => $this->request->getGet("id"),
                          "qty" => $cantidad+1
                      ));
                  }
                  return redirect()->back()->withInput();
                // return redirect()->route('panel_carrito');
        }


}