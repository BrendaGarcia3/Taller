<?php
namespace App\Controllers; 
use App\Models\producto_model;
use App\Models\categoria_model; 
use CodeIgniter\Controller;    

class crud_product_controller extends Controller {

    public function _construct () { 

        helper(['form', 'url']);
    } 


    //muestra lista de productos--
    public function index() {

        $productoModel = new producto_model();
        $data['productos'] = $productoModel->orderBy('id', 'ASC')->findAll();
        $data['title'] = "crud de productos";
       
        echo view('front/head_view', $data);
        echo view('back/usuario/panel/panel');
        echo view('back/productos/crud_productos');
        echo view('front/footer_view');
    }

    //crea un producto ---
    public function create() {
     
        $categoriasModel = new categoria_model();
        $data['categoria'] = $categoriasModel->getCategoria();

        $productoModel = new producto_model();
        $data['productos'] = $productoModel->orderBy('id', 'DESC')->findAll();
  
        $data['titulo'] = 'nuevo producto' ; 
        echo view('front/head_view', $data);
        echo view('back/usuario/panel/panel');
        echo view('back/productos/nuevo_producto');
        echo view('front/footer_view');
    }

    //inserta los datos
    public function store() {
        if ($this->request->getMethod() === 'post') {
            $productoModel = new producto_model(); 
        
            // tiene datos del formulario
            $data = [
                'nombre_producto' => $this->request->getVar('nombre_producto'),
                'categoria' => $this->request->getVar('categoria'),
                'stock' => $this->request->getVar('stock'),
                'stock_min' => $this->request->getVar('stock_min'),
                'precio' => $this->request->getVar('precio'),
                'precio_venta' => $this->request->getVar('precio_venta'),
                'eliminado' => $this->request->getVar('eliminado'),
            ];

            $imagen = $this->request->getFile('imagen');
            if ($imagen->isValid() && !$imagen->hasMoved()) {
                // Genera un nombre único para la imagen
                $newName = $imagen->getRandomName();

                // Mueve la imagen a la ubicación de almacenamiento
                $imagen->move('assets\img', $newName);

                // Guarda el nombre de la imagen en el array de datos
                $data['imagen'] = $newName;
            }

            $productoModel->insert($data);
            //return redirect(site_url('/crud_productos')); 
            return redirect()->to('/crud_productos');
        }
    }
  
    // muestra 1 solo producto forma 
    public function singleproducto($id = null) { 

        $productoModel = new producto_model();
                $data['producto'] = $productoModel->where('id', $id)->first();
                $data["title"] = "Editar un producto";
                echo view('front/head_view',$data);
                echo view('front/nav_view');
                echo view("back/productos/edit_producto", $data);
                echo view('front/footer_view');  
    }



    //ACTUALIZA LOS DATOS
    public function Update2() {
        $productoModel = new producto_model();
        $id = $this->request->getVar('id');

        // Obtiene el producto por su ID
        $data['producto'] = $productoModel->find($id);
        
        // Verifica si se ha enviado el formulario de edición
        if ($this->request->getMethod() === 'post') {
            // Obtén los datos del formulario
           /* $postData = []*/
    
           $postData = [
                'nombre_producto' => $this->request->getVar('nombre_producto'),
                'categoria' => $this->request->getVar('categoria'),
                'precio' => $this->request->getVar('precio'),
                'precio_venta' => $this->request->getVar('precio_venta'),
                'stock' => $this->request->getVar('stock'),
                'stock_min' => $this->request->getVar('stock_min'),
                'eliminado' => $this->request->getVar('eliminado'),
            ];

            // Procesa la carga de la imagen
            $imagen = $this->request->getFile('imagen');
            if ($imagen !== null && $imagen->isValid() && !$imagen->hasMoved()) {
                // Genera un nombre único para la imagen
                $newName = $imagen->getRandomName();

                // Mueve la imagen a la ubicación de almacenamiento
                $imagen->move('assets\img', $newName);

                // Guarda el nombre de la imagen en el array de datos
                $data['imagen'] = $newName;
            }

            // Actualiza los datos en la tabla productos
            $productoModel->update($id, $postData);

            //$productoModel = new producto_model(); 
            //$productoModel->insert($data);

            return $this->response->redirect(site_url('/crud_productos'));
            //return redirect()->to('/crud_productos');
        }
    }

    
        //   PAGINACION - enlaces manual 
        private function generatePaginationLinks($currentPage, $totalPages, $numLinks)
        {
            $pagination = '<nav><ul class="pagination">';
        
            // Botón "Anterior"
            if ($currentPage > 1) {
                $pagination .= '<li class="page-item"><a class="page-link" href="lista_producto?page=' . ($currentPage - 1) . '">Anterior</a></li>';
            }
        
            // Enlaces numerados
            $start = max(1, $currentPage - $numLinks);
            $end = min($totalPages, $currentPage + $numLinks);
        
            for ($i = $start; $i <= $end; $i++) {
                $active = ($i == $currentPage) ? ' active' : '';
                $pagination .= '<li class="page-item' . $active . '"><a class="page-link" href="lista_producto?page='  . $i . '">' . $i . '</a></li>';
            }
        
            // Botón "Siguiente"
            if ($currentPage < $totalPages) {
                $pagination .= '<li class="page-item"><a class="page-link" href="lista_producto?page='  . ($currentPage + 1) . '">Siguiente</a></li>';
            }
        
            $pagination .= '</ul></nav>';
            
            return $pagination;
        }
        


    
    //LISTA DE PRODUCTOS 
    public function listarProductos () { 

        $productoModel = new producto_model();
        $data['productos'] = $productoModel->orderBy('id', 'DESC')->findAll();

       //------------------------------------------------------------------------------
        //      PAGINACION
        $perPage = 10; // Número de filas por página
        $currentPage = $this->request->getVar('page') ? $this->request->getVar('page') : 1;
        $totalRows = count($data['productos']);
        $numLinks = 2; // Número de enlaces de paginación a mostrar

        // Calcula el número total de páginas
        $totalPages = ceil($totalRows / $perPage);

        // Asegúrate de que el número de página actual sea válido
        if ($currentPage < 1) {
            $currentPage = 1;
        } elseif ($currentPage > $totalPages) {
            $currentPage = $totalPages;
        }

        // Obtiene los productos para la página actual
        $offset = ($currentPage - 1) * $perPage;
        $data['productos'] = array_slice($data['productos'], $offset, $perPage);

        // Genera los enlaces de paginación manualmente
        $data['pagination'] = $this->generatePaginationLinks($currentPage, $totalPages, $numLinks);
  
        $data['titulo'] = 'productos' ; 
        echo view('front/head_view', $data);
        echo view('back/usuario/panel/panel');
        echo view('back/productos/lista_producto');
        echo view('front/footer_view');     

    }

    /*------------------------------------------------------------------------

    
    //ELIMINA UN PRODUCTO--
    public function delete($id = null){
        $productoModel = new producto_model();
        $data['productos'] = $productoModel->where('id', $id)->delete($id);
        return  redirect()->to('/crud_productos');
    }   

    /*-----------------------------------------------------------------
    //LISTA DE ELIMINADOS
        public function eliminados(){
            $productoModel = new Producto_model();

            // Obtiene solo los productos eliminados
            $data['productos'] = $productoModel->where('eliminado', 'SI')->findAll();

            // Carga las vistas necesarias
            echo view('front/header');
            echo view('front/navbar');
            echo view('back/producto/lista_eliminados', $data);
            echo view('front/footer');
        }
    ---------------------------------------------------------------------------*/

    //DESHABILITA UN PRODUCTO
    
    public function deshabilitar($id = null) {
        // Verifica si se ha enviado una solicitud POST o PATCH
        if ($this->request->getMethod() === 'post' || $this->request->getMethod() === 'patch') {
            $productoModel = new producto_model();

            // Actualiza el campo "habilitado" o "activo" del producto a 0 (deshabilitado)
            $productoModel->update($id, ['eliminado' => 'SI']);

            // Redirige a la página de lista de productos
            return redirect()->to('/crud_productos');
        }
    }


    //HABILITAR UN PRODUCTO
    public function habilitarProducto($id = null) {
        $productoModel = new producto_model();

        // Activar el producto por su ID
        $productoModel->update($id, ['eliminado' => 'NO']);

        // Redirige a la página de lista de productos eliminados
        return redirect()->to('/crud_productos');
    }



}
