<?php 
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\Usuarios_model;
  
class Login_controller extends BaseController
{
    public function index()
    {
        helper(['form','url']);    

        $data["title"]="loguearse";
        echo view('front/head_view',$data);
        echo view('front/nav_view');
        echo view ('back/login/login');
        echo view('front/footer_view');   

    } 
  
    public function auth()
    {
        $session = session();
        $model = new Usuarios_model();

        $rules = $this->validate([
            'email'    => 'required|min_length[4]|max_length[100]',
            'pass'     => 'required|min_length[3]'
        ]);

        if (!$rules) {
            $data["title"]="Registro"; 
            echo view('front/head_view',$data);
            echo view('front/nav_view');
            echo view('back/login/login', ['validation' => $this->validator]);
            echo view('front/footer_view');
            return;
        }

        //traemos los datos del formulario
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('pass');
        
        $user = $model->where('email', $email)->first();

        if($user){
            $pass = $user['pass'];
            $ba= $user['baja'];
                if ($ba == 'SI'){
                     $session->setFlashdata('msg', 'usuario dado de baja');
                     return redirect()->to('/login');
                 }
                    //Se verifican los datos ingresados para iniciar, si cumple la verificaciòn inicia la sesion
                    $verify_pass = password_verify($password, $pass);
                   //password_verify determina los requisitos de configuracion de la contraseña
                if($verify_pass){
                    $ses_data = [
                    'id' => $user['id'],
                    'nombre' => $user['nombre'],
                    'apellido'=> $user['apellido'],
                    'email' =>  $user['email'],
                    'usuario' => $user['usuario'],
                    'perfil_id'=> $user['perfil_id'],
                    'isLoggedIn'  => TRUE
                ];
                  //Se se cumple la verificacion inicia la sesiòn  
                  $session->set($ses_data);

                  session()->setFlashdata('msg', 'Bienvenido a tu perfil!!');
                  return redirect()->to('/panel');
            }else{  
                 //no paso la validaciòn de la password
               session()->setFlashdata('msg', 'Password Incorrecta');
               return $this->response->redirect(site_url('/login'));
         }   
        }else{
            $session->setFlashdata('msg', 'No Existe el Email o es Incorrecto');
            return redirect()->to('/login');
      } 
    
  }

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/login');
    }
} 
