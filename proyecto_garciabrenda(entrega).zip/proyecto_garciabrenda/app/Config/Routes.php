<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
$routes->get('/principal', 'Home::principal');
$routes->get('/nosotros', 'Home::SobreNosotros');
$routes->get('/comercializacion', 'Home::comercializacion');
$routes->get('/terminosYusos', 'Home::terminosYusos');
$routes->get('/contacto', 'Home::contacto');
$routes->get('/carrito', 'Home::carrito');
$routes->get('/registro', 'Home::registro');





//BACK-END

// LOGIN Y REGISTRO
$routes->post('/send-login','Login_controller::auth'); 
$routes->post('/registro_controller/formValidation', 'registro_controller::formValidation');
$routes->get('/registro', 'registro_controller::index');
$routes->get('/login', 'Login_controller::index');
$routes->get('/panel', 'Panel_controller::index',['filter' => 'auth']);
$routes->get('/logout', 'Login_controller::logout');


//CRUD DE USUARIOS  
$routes->get('/crud_usuario', 'crud_usuarios_controller::index');
$routes->post('/update', 'crud_usuarios_controller::update'); 
$routes->get('delete/(:num)', 'crud_usuarios_controller::delete/$1'); 
//editar
$routes->get('/edit_usuario/(:num)', 'crud_usuarios_controller::singleUser/$1'); 
//agregar
$routes->get('/registro', 'crud_usuarios_controller::create'); 


// PRODUCTOS
$routes->get('/crud_productos', 'crud_product_controller::index'); 
$routes->get('delete/(:num)', 'crud_product_controller::delete/$1'); 
$routes->post('/Update2', 'crud_product_controller::Update2'); 
//agregar 
$routes->get('/nuevo_producto', 'crud_product_controller::create'); 
$routes->post('/guardar_nuevoP', 'crud_product_controller::store');
//editar
$routes->get('/edit_producto/(:num)', 'crud_product_controller::singleproducto/$1'); 
//deshabilitar
$routes->get('deshabilitar/(:num)', 'crud_product_controller::deshabilitar/$1'); 
//Listar
$routes->get('/lista_producto', 'crud_product_controller::listarProductos');


//CATALOGO
$routes->get('/catalogo2','Home::catalogo2');

//agrega el producto al carrito
$routes->get('/carrito_agrega', 'carrito_controller::add');
$routes->post('/carrito_agrega', 'carrito_controller::add');
//muestra todos los productos del catalogo
$routes->get('/catalogo2', 'carrito_controller::catalogo2',['filter' => 'auth']);

//CARRITO
//muestra la parte view del carrito
$routes->get('/Carrito','carrito_controller::index',['filter'=>'auth']);
//actualiza los datos del carrito 
$routes->get('/carrito_actualiza','carrito_controller::actualiza_carrito',['filter'=>'auth']);
//eliminar todo el carrito
$routes->get('/borrar','carrito_controller::borrar_carrito',['filter'=>'auth']);
//elimina un solo producto del carrito --corregir
$routes->get('carrito_elimina/(:any)','carrito_controller::remove/$1',['filter'=>'auth']);
//realiza la compra del producto - muestra la factura
$routes->get('/carrito_comprar', 'ventas_controller::registro_venta',['filter'=>'auth']);



//Perfil 
$routes->get('/perfil', 'Usuario_controller::perfil');
$routes->get('/perfil', 'Usuario_controller::perfil_index');

//Contacto - consultas
$routes->post('consultas/guardar', 'consultas_controller::guardarConsulta');




/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */

 if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
