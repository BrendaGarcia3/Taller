<img src="assets/img/perfumesBN.jpg" class="d-block w-100 rounded"  width="350%" y height="490%" alt=" " ><br> <!-- medida relativa usando % -->

<br> <h5 class= "slogan"> "Tu perfume es tu mensaje, tu esencia es tu slogan"  </h5> <br>

 <!--CARRUSEL ------->

      <div id="carouselExampleInterval" class="carousel slide w-50 mx-auto" data-bs-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active" data-bs-interval="10000">
            <img src="assets/img/perfume-given.jpg" class="d-block w-100 rounded" alt="Jadore-dior.jpg" >
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="assets/img/hombre.jpg" class="d-block w-100 rounded" alt="Boss.jpg"  >
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="assets/img/perfumesAAA.jpeg" class="d-block w-100 rounded" alt="Boss.jpg"  >
          </div>
          <div class="carousel-item" data-bs-interval="2000">
            <img src="assets/img/libre_portada.jpg" class="d-block w-100 rounded" alt="Boss.jpg"  >
          </div>
          <div class="carousel-item">
            <img src="assets/img/fragancias-perfume.jpg" class="d-block w-100 rounded"  alt=" ">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
      <br>   <br>


<!-----------------Productos------------------------------------->
<hr size="8px"> <br> 

<div class="text-center"> 
  <h1> Nuestros últimos ingresos </h1>
</div> 
<br>

<div class="container my-5">
  <div class="row justify-content-center g-4">
  
    <!-- Card 1 para que sea responsive dependiendo del aparato usado-->
    <div class="col-12 col-sm-6 col-md-4 d-flex justify-content-center">
      <div class="card" style="width: 18rem;">
        <img src="assets/img/AcquaDiGio.jpg" class="card-img-top" alt="Perfume 1">
        <div class="card-body">
          <h5 class="card-title">Acqua DiGio - Profondo</h5>
          <p class="card-text">Perfume hombre</p>
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item">Precio: $200.000</li>
          <li class="list-group-item">Stock: 12 unidades</li>
        </ul>
        <div class="card-body text-center">
          <button class="btn btn-primary">Comprar</button>
          <button class="btn btn-secondary">Detalles</button>
        </div>
      </div>
    </div>

    <!-- Card 2 -->
    <div class="col-12 col-sm-6 col-md-4 d-flex justify-content-center">
      <div class="card" style="width: 18rem;">
        <img src="assets/img/invictus.jpg" class="card-img-top" alt="Perfume 2">
        <div class="card-body">
          <h5 class="card-title">Paco Rabanne - Invictus Legend</h5>
          <p class="card-text">Perfume hombre</p>
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item">Precio: $116.000</li>
          <li class="list-group-item">Stock: 8 unidades</li>
        </ul>
        <div class="card-body text-center">
          <button class="btn btn-primary">Comprar</button>
          <button class="btn btn-secondary">Detalles</button>
        </div>
      </div>
    </div>

    <!-- Card 3 -->
    <div class="col-12 col-sm-6 col-md-4 d-flex justify-content-center">
      <div class="card" style="width: 18rem;">
        <img src="assets/img/my_way.jpg" class="card-img-top" alt="Perfume 3">
        <div class="card-body">
          <h5 class="card-title">Giorgio Armani - My Way</h5>
          <p class="card-text">Perfume mujer</p>
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item">Precio: $198.000</li>
          <li class="list-group-item">Stock: 5 unidades</li>
        </ul>
        <div class="card-body text-center">
          <button class="btn btn-primary">Comprar</button>
          <button class="btn btn-secondary">Detalles</button>
        </div>
      </div>
    </div>

  </div>
</div>



<!-------------------------------------------------------------------------------------->
<!-- Agrega los enlaces a Bootstrap JS y jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


  <hr size="8px"> <br> 
  <h1 class="equipo"> Trabaja con Nosotros</h1>

  <h1 class="titulo"> <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-report" width="44" height="44" viewBox="0 0 24 24" stroke-width="2" stroke="#00b341" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
        <path d="M8 5h-2a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h5.697" />
        <path d="M18 14v4h4" />
        <path d="M18 11v-4a2 2 0 0 0 -2 -2h-2" />
        <rect x="8" y="3" width="6" height="4" rx="2" />
        <circle cx="18" cy="18" r="4" />
        <path d="M8 11h4" />
        <path d="M8 15h3" />
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-mood-smile" width="44" height="44" viewBox="0 0 24 24" stroke-width="2" stroke="#fd0061" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
        <circle cx="12" cy="12" r="9" />
        <line x1="9" y1="10" x2="9.01" y2="10" />
        <line x1="15" y1="10" x2="15.01" y2="10" />
        <path d="M9.5 15a3.5 3.5 0 0 0 5 0" />
      </svg>

  </h1>  <br>  <br>
         
      <p class="text-justify"> Si querés ser parte de nuestro equipo de trabajo envianos tu CV a nuestro correo electrónico
      Veronaperfumes@gmail.com, mandanos tus datos especificando: <br> Nombre y Apellido, DNI y puesto al cuál desea postularse  
      </p> <br> <br>
       

</body>
     



