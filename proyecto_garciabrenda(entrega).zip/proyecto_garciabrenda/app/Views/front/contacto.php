<html> <br>
  <div class= "text-center"> 
      <h1 class="titulo1">Contacto</h1>
  </div><br><br>

 <div class="container text-center">
    <div class="row align-items-start">
       <div class="col-md-6">
                <div class= "text-center">
                    <h3 class="contacto"> - Horarios de Atención -</h3> <br> 
                </div>
          <h6>  Online </h6> <br>   
          <p> (La pagina solo funcionará para realizar compras en los siguientes horarios: ) </p>
          <p> Lunes a Viernes de 9hs a 12hs y de 17hs a 20:30hs </p>
          <p> Sabados de 9hs a 11hs y de 17:30 a 20:30hs </p><br>

          <h6> En el local </h6> <br>
          <p> Lunes a Viernes de 9hs a 12:30hs y de 17hs a 21hs </p>
          <p> Sabados de 9hs a 12:30hs y de 17:30 a 21hs </p><br>

          <h6>Contactate con nosotros para cualquier pregunta o consulta que quieras hacernos! </h6><br> <br>
          
             <blockquote> 
                    Titular de la Empresa: Garcia Brenda   <br> 
                    Verona Fragancias S.R.L.<br> 
                    Ubiacion de nuestro local: Hipólito Yrigoyen 2058 <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-pin" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="#00b341" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M15 4.5l-4 4l-4 1.5l-1.5 1.5l7 7l1.5 -1.5l1.5 -4l4 -4" />
                        <line x1="9" y1="15" x2="4.5" y2="19.5" />
                        <line x1="14.5" y1="4" x2="20" y2="9.5" />
                      </svg><br>
             </blockquote>
       
             <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-phone" width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <path d="M5 4h4l2 5l-2.5 1.5a11 11 0 0 0 5 5l1.5 -2.5l5 2v4a2 2 0 0 1 -2 2a16 16 0 0 1 -15 -15a2 2 0 0 1 2 -2" />
              </svg> Numero de celular (con WhatsApp): 3794561232 <br><br> 
              
          
            <p> Nuestro correo electrónico: 
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-mail" width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <rect x="3" y="5" width="18" height="14" rx="2" />
                    <polyline points="3 7 12 13 21 7" />
                  </svg> Veronaperfumes@gmail.com
           </p>
       </div> 
        <!---------------FORMULARIO----------------------------------------------------------->
        <div class="col-md-6">
            <h2>Contactanos</h2>
              <form action="<?= base_url('consultas/guardar') ?>" method="post">
                  <div class="card-body">
                      <div class="mb-3">
                          <label for="nombre" class="form-label">Nombre</label>
                          <input type="text" class="form-control" name="nombre" placeholder="Nombre"  value="<?= old('nombre') ?>">
                          <?= session('validation') ? session('validation')->getError('nombre') : '' ?>
                      </div>
                      <div class="mb-3">
                          <label for="apellido" class="form-label">Apellido</label>
                          <input type="text" class="form-control" name="apellido" placeholder="Apellido"  value="<?= old('apellido') ?>">
                          <?= session('validation') ? session('validation')->getError('apellido') : '' ?>
                      </div>
                      <div class="mb-3">
                          <label for="email" class="form-label">Email</label>
                          <input type="email" class="form-control" name="email" placeholder="email" value="<?= old('email') ?>">
                          <?= session('validation') ? session('validation')->getError('email') : '' ?>
                      </div>
                      <div class="mb-3">
                          <label for="telefono" class="form-label">Teléfono</label>
                          <input type="tel" class="form-control" name="telefono" placeholder="telefono" value="<?= old('telefono') ?>">
                          <?= session('validation') ? session('validation')->getError('telefono') : '' ?>
                      </div>
                      <div class="mb-3">
                          <label for="mensaje" class="form-label">Mensaje</label>
                          <textarea class="form-control" name="mensaje"> <?= old('mensaje') ?></textarea>
                          <?= session('validation') ? session('validation')->getError('mensaje') : '' ?>
                      </div>
                      <button type="submit" class="btn btn-primary">Enviar</button>
                   </div>
                </form>
         </div>
    </div>
</div>
 <br> <br>
<!------------------MAPA------------------------------------------------------------------------------>
<div class="text-center">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3539.977819850444!2d-58.827337024755!3d-27.46994987631948!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94456b5e223f9415%3A0x4db5b4ceae2a1a5b!2sHip%C3%B3lito%20Yrigoyen%202058%2C%20W3400ATP%20Corrientes!5e0!3m2!1ses!2sar!4v1745338886558!5m2!1ses!2sar" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div> <br> <br>
  <!------------------------------------------------------------------------------------------->
    <h4 class="titulo1"> Seguinos en nuestras redes sociales y enterate de todo!! </h4>    
    <div class="text-center"> 
            <a href="https://www.instagram.com/">
                <svg  xmlns="" class="icon icon-tabler icon-tabler-brand-instagram" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="#a905b6" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <rect x="4" y="4" width="16" height="16" rx="4" />
                        <circle cx="12" cy="12" r="3" />
                        <line x1="16.5" y1="7.5" x2="16.5" y2="7.501" />
                </svg>
            </a>
            <a href="https://es-la.facebook.com/"> 
                    <svg xmlns="" class="icon icon-tabler icon-tabler-brand-facebook" width="32" height="32" viewBox="0 0 24 24" stroke-width="2" stroke="#00abfb" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                </svg>   
            </a> <br>
    </div> 
    <p class="text-center"> Verona_perfum</p> 
    <br><br><br> <br><br>

</html>
