
<footer>

    <div class="text-center footer-style">
        <div class="container">
            <div class="row">
                <div class="col-md-4 footer-col">
                    <h5 class="titulo2"> Nuestras Redes</h5>
                    <h6 class="titulo2">  Seguinos en Instagram y tambien en Facebook! </h6>
                     <div class="text-center"> 
                            <a href="https://www.instagram.com/">
                                <svg  xmlns="" class="icon icon-tabler icon-tabler-brand-instagram" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="#a905b6" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <rect x="4" y="4" width="16" height="16" rx="4" />
                                        <circle cx="12" cy="12" r="3" />
                                        <line x1="16.5" y1="7.5" x2="16.5" y2="7.501" />
                                </svg>
                            </a>
                            <a href="https://es-la.facebook.com/"> 
                                    <svg xmlns="" class="icon icon-tabler icon-tabler-brand-facebook" width="32" height="32" viewBox="0 0 24 24" stroke-width="2" stroke="#00abfb" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                                </svg>   
                            </a> <br>
                     </div> 
                </div>
                <div class="col-md-4 footer-col">
                        <h5 class="titulo2"> Contacto</h5>
                        <h6 class="titulo2"> Veronaperfumes@gmail.com  </h6>
                    
                    <img class="foto1" src="assets/img/Logo.jpg" alt="imagen 1"  width = "100"  height= "100">

                </div>
                <div class="col-md-4 footer-col">
                    <h5 class="titulo2"> Recibe Noticias!!</h5>
                    <h6 class="titulo2"> Recibí noticias sobre todos los nuevos productos y promociones que tenemos para vos.
                    Solo debés hacer clic en <A  href="<?php echo base_url('contacto'); ?>" > Contacto </A>  </h6>
                
                
                </div>
            </div>
        </div><br><br><br>
        <h6 class="titulo2"> El uso de este sitio está sujeto a las condiciones de uso expresas. Al utilizar este sitio, tú indicas que aceptas cumplir con estos Términos y Servicios. </h6>
        <br>
    </div>
</footer>

    <script src= "<?php echo base_url("assets/js/popper.min.js"); ?>"> </script>
    <script src= "<?php echo base_url( "assets/js/bootstrap.min.js") ; ?>"> </script>
    <script src= "<?php echo base_url("assets\js\bootstrap.bundle.min.js"); ?>"></script>
    

</html>
