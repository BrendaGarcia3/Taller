<!DOCTYPE html>
<html lang= 'es'>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  

    <title>Inicio</title>
    
    <link rel="stylesheet" href= "<?php echo base_url("assets/css/bootstrap.min.css"); ?>"> 
    <link rel="stylesheet" href= "<?php echo base_url("assets/css/style.css"); ?>" > 
    <!-- Agrega los enlaces a Bootstrap CSS y JS -->
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->

</head>

<header>

    <div class="text-center header-style">
           <h1 class="titulo"> Verona </h1>
            <h4 class="titulo">- Perfumería -</h4>  <br><br>
    </div> 
</header> 

<body>


