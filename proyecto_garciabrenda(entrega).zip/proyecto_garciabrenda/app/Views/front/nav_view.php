<?php
    $session = session();
?>
<!--BARRA DE NAVEGACION  -->
<nav class="navbar bg-white border-bottom border-body" data-bs-theme="white">

  <div class="bg-white p-1">
      <!--<a class= "nav-link-brand" href="<?php echo base_url('principal'); ?>"> -Menú-</a> --> 
    
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
           <ul class="navbar-nav"> <br>        
             <li class="nav-item">
                <a class="nav-link active" href="<?php echo base_url('principal'); ?>">Inicio</a>
              </li>
              <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="<?php echo base_url('nosotros'); ?>">Sobre Nosotros</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('comercializacion'); ?>" >Comercialización</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('terminosYusos'); ?>" >Términos y Usos</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('contacto'); ?>">Contacto</a>
              </li>

              <?php if(session()->get('isLoggedIn')): ?>
              <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url('logout'); ?>">Cerrar sesión</a>
              </li>
              <?php   else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url('registro'); ?>" >Registrarse</a>
                </li> 
                <li class="nav-item">
                      <a class="nav-link" href="<?php echo base_url('login'); ?>" >Mi cuenta<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user" width="24" height="24" viewBox="0 0 24 24" stroke-width="1.5" stroke="#009988" fill="none" stroke-linecap="round" stroke-linejoin="round">
                              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                              <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0" />
                              <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                            </svg></a>
                </li>
              <?php endif;?>

              <?php if(session()->get('perfil_id') ==  1): ?>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url('panel'); ?>">IR ADMIN</a>
                  </li>
                <?php   else: ?>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url('panel'); ?>">Volver</a>
                  </li>
              <?php endif;?>
            </ul>
         </div>
   </div>
  
</nav>
