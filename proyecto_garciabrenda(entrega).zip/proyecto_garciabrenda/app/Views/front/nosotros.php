<html> 
<div class= "quienesomos"> 
  <div class="container">
        <div class="row mt-5 Nosotros">
          <div class="text" style="text-align: justify">
          <div class="col">
             
              <h1 class="titulo1"> ¿Quienes somos?  
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-home" width="44" height="44" viewBox="0 0 24 24" stroke-width="2" stroke="#00bfd8" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <polyline points="5 12 3 12 12 3 21 12 19 12" />
                  <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" />
                  <path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" />
                  </svg> 
              </h1> <br> <br> 

              <p> En Verona, creemos que cada fragancia es una historia. Somos una perfumería dedicada a ofrecer una experiencia sensorial 
                 única, combinando calidad, elegancia y atención personalizada. Nuestra pasión por el mundo de los aromas nos convierte 
                 en el lugar ideal para quienes buscan más que un perfume: buscan identidad.
              </p>

              <h5> 📖 Nuestra Historia: </h5>
              <p>  Verona nació del sueño de acercar la magia de las fragancias a cada persona. Empezamos como un pequeño local con
                   gran amor por el detalle, y fuimos creciendo gracias a la confianza de nuestros clientes y el compromiso con la excelencia.
                  Hoy, somos un referente local en perfumes originales, productos importados y asesoramiento personalizado. 
              </p> <br> 
             
                  <h5>Logros clave:</h5>
                  <ul>
                    <li>Ampliación de nuestro catálogo con marcas exclusivas.</li>
                    <li>Fidelización de una comunidad de clientes que nos elige día a día.</li>
                    <li>Expansión a través de redes sociales.</li>
                  </ul>   <br>    
                   
                  <h5>Nuestros Valores y Principios</h5>
                    <ul>
                      <li><strong>Calidad:</strong> Productos originales y de primeras marcas.</li>
                      <li><strong>Confianza:</strong> Relación personalizada con cada cliente.</li>
                      <li><strong>Pasión:</strong> Amor por lo que hacemos.</li>
                      <li><strong>Respeto:</strong> A clientes, proveedores y medio ambiente.</li>
                      <li><strong>Innovación:</strong> Nuevas tendencias y propuestas.</li>
                    </ul><br> 

    
                  <h5> Misión y Visión </h5>
                  <h6> -> Misión  </h6>
                      <p>  Ofrecer fragancias y productos de belleza que inspiren, realcen la personalidad y generen emociones, 
                        brindando una atención cálida y profesional.
                        </p>
                  <h6> -> Visión </h6>
                  <p>  Ser la perfumería de referencia en nuestra comunidad, reconocida por la calidad de sus productos, 
                        la excelencia en el servicio y la cercanía con nuestros clientes.
                  </p><br> 
                  

             <h5>Testimonios y Reseñas </h5> 
             <div class="bg-transparent p-3">
                  <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#testimoniosCollapse" aria-expanded="false" aria-controls="testimoniosCollapse">
                    Ver Testimonios
                  </button>
                  <div class="collapse mt-3" id="testimoniosCollapse">
                      <div class="card card-body">
                          <p>
                            "Siempre encuentro lo que busco, y la atención es increíble. ¡Gracias Verona!"<br>
                            — Lucía G., clienta habitual
                          </p>
                          <p>
                            "Me asesoraron con mucha paciencia para encontrar el perfume ideal. ¡Recomiendo 100%!"<br>
                            — Martín D., cliente nuevo
                          </p>
                          <p>
                            "¡Verona es sinónimo de buen gusto y calidad! Compro para mí y para regalar."<br>
                            — Sofía R., clienta frecuente
                          </p>
                          <p>
                            "Productos de primera calidad y una asesoría que marca la diferencia. ¡Gracias Verona!"<br>
                            — Diego P., cliente fiel
                          </p>
                        </div>
                    </div>
               </div> <br><br><br><br>

               <div class="row mt-5 text-center">
                    <div class="col-md-6 mb-4">
                      <img src="assets/img/equipo.jpg" class="img-fluid rounded" alt="Equipo Verona">
                    </div>
                    <div class="col-md-6 mb-4">
                      <img src="assets/img/grupo_trabajo.png" class="img-fluid rounded" alt="Grupo de Trabajo Verona">
                    </div>
                 </div>   
         </div> 
         </div> 
       </div>
    </div>
 </div> <br>


</html> 



