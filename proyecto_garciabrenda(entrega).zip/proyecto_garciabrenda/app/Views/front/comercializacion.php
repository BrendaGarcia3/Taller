<html> <br>
 <h1 class="titulo1"> Comercialización </h1> <br>
 
  <div class="container text-center">
    <div class="row align-items-start">
      
          <div class="col">
              <h3> Medios de Pago </h3>
              <p> 
                Trabajamos con todos los medios de Pago, efectivo, mercado pago, tarjetas de débito y crédito de todos los bancos.
                En el caso de abonar en efectivo se otorgará un descuento (el valor del descuento dependerá del producto que haya comprado)
              </p><br> 
              <p> Para las Localidades y el resto de las Provincias el pago del producto debe ser con antelación. </p>
            
              <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-coin" width="40" height="40" viewBox="0 0 24 24" stroke-width="1.5" stroke="#00bfd8" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <circle cx="12" cy="12" r="9" />
                <path d="M14.8 9a2 2 0 0 0 -1.8 -1h-2a2 2 0 0 0 0 4h2a2 2 0 0 1 0 4h-2a2 2 0 0 1 -1.8 -1" />
                <path d="M12 6v2m0 8v2" />
                </svg> 
              <br> <br>
              <img src="assets/img/MediosDePago.png" class="img-fluid rounded"  alt="pagos.png" >
           </div>

            <div class="col">
                <h3> Envíos </h3>
                <p>  Una vez finalizada la compra verificaremos los datos para el envío.</p> <br>
                <h6> Formas de Envíos </h6>
                <p> Los métodos de envíos que ofrece nuestra empresa son: </p> <br> 
                <p>En la ciudad de Corrientes capital contamos con motomandado, el costo (que se deberá abonar cuando el motomandado llegue a destino) dependerá de la distancia a la cual se deba entregar el producto. El envío se realizará en el día y horario pactado 
                  con el cliente </p> <br> 
                <p> Fuera de la capital contamos con Correo Argentino para realizar la entrega, en este caso el día y hora del envío será definido por la empresa encargada del envío. Podría demorar de 3 a 5 días hábiles </p>
                <p> El costo de envío queda a cargo del cliente, pero con una compra mayor a $100.000 (cien mil) el envío será gratis</p> 
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-package" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="#ff9300" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <polyline points="12 3 20 7.5 20 16.5 12 21 4 16.5 4 7.5 12 3" />
                    <line x1="12" y1="12" x2="20" y2="7.5" />
                    <line x1="12" y1="12" x2="12" y2="21" />
                    <line x1="12" y1="12" x2="4" y2="7.5" />
                    <line x1="16" y1="5.25" x2="8" y2="9.75" />
                    </svg>
             </div>
      
    </div>
  </div> <br> 
    <div class= "text-center mt-5">
        <p><strong>Dato a tener en cuenta:</strong> Solo realizamos envíos en las provincias de Corrientes, Chaco, Misiones, Entre Ríos, Santa Fe y Formosa.</p>
    </div>
</html>




