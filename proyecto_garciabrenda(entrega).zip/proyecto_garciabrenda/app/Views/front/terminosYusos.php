<html> 
<div class="container">
  <div class="row">
    <div class="col">
      <div class="row mt-4 TerminosyUsos">
        <div class="col">
        <ol>

        <h1 class="titulo1"> Términos y Usos  <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-alert-triangle" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ff4500" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <path d="M12 9v2m0 4v.01" />
            <path d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75" />
            </svg>
        </h1>  <br> 
        
        <h4 class="terminos"> Políticas de Cambio </h4> <br> 

        <p class="text-justify"> Los productos adquiridos por internet enviados desde nuestra sucursal no tienen cambio ni
            devolución, excepto que se deba a un fallo de fábrica </p> <br> 

        <p class="text-justify">  Si tu problema se debe a un fallo de fábrica y sos de Corrientes Capital podes acercarte a nuestra sucursal
            para realizar el cambio solicitado, vas a poder canjearlo por el mismo producto (si existe en stock), por un 
            producto de igual valor o de mayor valor pero se deberá abonar la diferencia. <br>
            En cambio, si sos de otra ciudad o Provincia nos hacemos cargo del costo del envío y el encargo se realizará
            inmediatamente si el producto está en stock, en el caso de no estar en stock se trendá una demora de 5 dias 
            aproximadamente</p>  <br>

       <h4 class="terminos"> Solicitud</h4> <br> 

       <p class="text-justify"> Para solicitar un cambio del producto deberá comuicarse a nuestro numero telefónico 
        (WhatsApp): 3794561232 o a nuestro correo electrónico Veronaperfumes@gmail.com y enviarnos tus datos 
        con el número de compra.Una vez realizada la operación nosotros nos pondremos en contacto con usted en el 
         lapso de 12hs.</p> <br> 
        
       <h4 class="devolucion"> Las devoluciones solo pueden ser realizadas durante los 15 dias siguientes a la compra.</h4> <br> <br> 
       
       <h4 class="terminos"> PROMOCIONES NO ACUMULABLES </h4> <br> 
       <p class="text-justify"> Las ofertas y promociones vigentes no son acumulables entre sí. Ante dudas estamos al 100% a tu disposición </p> <br>

       <h4 class="terminos"> Envíos en la ciudad </h4> <br> 

        <p class="text-justify"> El cliente podrá realizar su compra online y solicitar que lo enviemos dentro de la ciudad de Corrientes, debeá dejar sus datos 
            (nombre, direccion y numero telefónico). Una vez recibida la compra en su domicilio deberá mostrar el ticket de compra online. </p>  <br>

         <h4 class="terminos"> Envíos fuera de la Capital</h4> <br> 

        <p class="text-justify"> Los envíos serán a través de Correo Argentino, a domicilio</p> <br>
        <p class="text-justify"> El costo del envío corre a cuenta del cliente. A partir del momento en que el servicio de correos 
                    se hace cargo del paquete podrá seguir su producto en la página de Correo Argentino</p> <br>
        <p class="text-justify"> En caso de que Ud. se encuentre fuera de su domicilio al momento de la entrega, la empresa de correos 
                    le dejará un aviso. Una vez que el servicio posee su paquete queda en responsabilidad del cliente el retiro de su producto.
                    Si el producto no se retira en tiempo y forma se devuelve a Verona y el cliente deberá abonar nuevamente el envío 
                    para poder recibirlo.
        </p> <br>

        </ol> 
        </div>
      </div>
    </div>
  </div>
</div><br> <br>

</html> 






