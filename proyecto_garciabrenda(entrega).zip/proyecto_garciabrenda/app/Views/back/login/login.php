<main>
    <div class="container text-center mt-5">
          <h6 class="text">------ Para la compra de productos debe iniciar sesión ------</h6> <br><br>
        <div>
            <!--recuperamos datos con la función Flashdata para mostrarlos-->
                <?php if (session()->getFlashdata('success')) {
                    echo "
                    <div class='mt-3 mb-3 ms-3 me-3 h4 text-center alert alert-success alert-dismissible'>
                      <button type='button' class='btn-close' data-bs-dismiss='alert'></button>" . session()->getFlashdata('success') . "
                    </div>";
                  } ?>
       </div>
          <!-- php $validación = \Config\Services::validación(); Esto carga automáticamente el archivo Config\Validation que contiene configuraciones para incluir múltiples conjuntos de reglas -->
            <?php $validation = \Config\Services::validation(); ?>

   
    <div class="container mt-1 mb-1 d-flex justify-content-center">
      <div class="card1" style="width: 50%; ">
          <div class="card-header text-center"><br>
                
                  <h3 class="login">Inicio de sesión</h3>
          </div>  <br>
                <form method="post" action="<?php echo base_url('/send-login') ?>">
                  
                <div class="mb-4">
                      <label for="exampleInputUsername" class="form-label">Email</label>
                    <input type="text" name="email" value="<?php echo set_value('email')?>" class="form-control" placeholder="Email">
                    <!--<input type="email" class="form-control" id= "exampleInputEmail1" aria-describedby="emailHelp"> -->
                    <?php if ($validation->getError('email')) { ?>
                            <div class='alert alert-danger mt-2'>
                                <?= $error = $validation->getError('email'); ?>
                            </div>
                            <?php } ?>
                    <div id="emailHelp" class="form-text">No se compartirán los datos ingresados</div>
                  </div>

                  <div class="mb-4">
                      <label for="exampleInputPassword1" class="form-label">Contraseña</label>
                      <input name="pass" type="password" class="form-control" placeholder="contraseña" id="exampleInputPassword1">
                      <!-- Error -->
                      <?php if ($validation->getError('pass')) { ?>
                            <div class='alert alert-danger mt-2'>
                                <?= $error = $validation->getError('pass'); ?>
                            </div>
                            <?php } ?>
                  </div>
                  <!--<button type="submit" class="btn btn-primary">Iniciar sesión</button> -->
                  <button class="pushable" >
                      <span class="shadow"></span> 
                      <span class="edge"></span> 
                      <span class="front"> Iniciar sesión </span> 
                  </button>
                  
                </form>

       </div>
    </div>
 </div>
 </main>
<br>
<br>
<br>
<br>



