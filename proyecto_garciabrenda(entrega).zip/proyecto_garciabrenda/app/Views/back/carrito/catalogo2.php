<?php
//       BUSCADOR //

// Iniciar sesión solo si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Datos de conexión a la base de datos
$host = "localhost";
$user = "root";
$password = "";
$dbname = "antonella_garcia";

// Crear conexión
$cons = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
//if ($cons->connect_error) {
 //   die("Error de conexión: " . $cons->connect_error); }


// Inicializar variables
$query = "SELECT * FROM productos";
$params = [];
$mostrarBotonVolver = false; // Control para mostrar el botón de "Volver"

// Buscar si se envió el formulario
if (isset($_GET['enviar']) && !empty($_GET['busqueda'])) {
    $busqueda = $cons->real_escape_string($_GET['busqueda']);
    $query = "SELECT * FROM productos WHERE nombre_producto LIKE ?";
    $params[] = "%$busqueda%";
    $mostrarBotonVolver = true; // Activar el botón de "Volver"
}

// Preparar y ejecutar consulta
//almacena sentencia  $stmt
$stmt = $cons->prepare($query);
if (!empty($params)) {
    $stmt->bind_param("s", ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

?> 
<!--------------------------------------------------------------------------------------------------->

<!-- CATEGORIAS --> 
 <?php
//encunetra las categorias 
$categoriaModel = new \App\Models\categoria_model();
$categorias = $categoriaModel->findAll();

// Selecciona la categoría actual, si está definida
$categoriaSeleccionada = isset($_GET['categoria']) ? $_GET['categoria'] : null;   // isset verifica si una variable está definida y no es null
?>


      <!------Columna Categorias--->
<br> <br>  <br>     
      <div class="col-md-3">
            <h3>Categorías</h3>
            <ul class="list-group">
                <li class="list-group-item <?= empty($categoriaSeleccionada) ? 'archivo' : '' ?>">
                    <a href="<?= site_url('catalogo2') ?>">Todas las categorías</a>
                </li>
                <?php foreach ($categorias as $categoria): ?>
                    <li class="list-group-item <?= ($categoriaSeleccionada == $categoria['id']) ? 'archivo' : '' ?>">
                        <a href="<?= site_url('catalogo2?categoria=' . $categoria['id']) ?>">
                        <?= $categoria['descripcion'] ?>  </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        



    <!-- Buscador de productos --> 
    <div class="container mt-4">
            <nav class="navbar bg-body-tertiary">
                <div class="container-fluid">
                    <form class="d-flex" role="search" method="get" action="">
                        <input class="form-control me-2" type="search" name="busqueda" placeholder="Buscar Producto" required>
                        <input class="btn btn-outline-success" type="submit" name="enviar" value="Buscar">
                    </form>
                </div>
            </nav>
    </div>    
    <!-- Botón para volver a la tabla completa -->
        <?php if ($mostrarBotonVolver): ?>
            <div class="mt-3">
                <a href="catalogo2" class="btn btn-secondary">Volver</a>
            </div>
        <?php endif; ?>




    <!-- contenedor de los productos--> 
    <div class="container mb-4" enctype="multipart/form-data">  <br>
        <div class="row justify-content-start">
                        <?php 
                        $productosModel = new \App\Models\producto_model();
                        $productos = $productosModel->findAll();

                    if (empty($productos)) : ?>
                    <p class="text-center">No existen productos disponibles</p>
                    <?php else : ?>
                    <?php foreach($productos as $producto): ?>
                <div class="col-3 mb-4"> 
                    <div class="card" style="width: 18rem; height:400px; max-height:390px">
                            
                        <img src="<?php echo base_url("assets/img/" . $producto['imagen']); ?>" class="card-img-top" alt="" height="200">
                       <div class="card-body">
                                <h5 class="card-title"><?php echo $producto['nombre_producto']?></h5> 
                                <p> 
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-circle-check-filled" width="16" height="16" viewBox="0 0 24 24" stroke-width="1.5" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                    <path d="M17 3.34a10 10 0 1 1 -14.995 8.984l-.005 -.324l.005 -.324a10 10 0 0 1 14.995 -8.336zm-1.293 5.953a1 1 0 0 0 -1.32 -.083l-.094 .083l-3.293 3.292l-1.293 -1.292l-.094 -.083a1 1 0 0 0 -1.403 1.403l.083 .094l2 2l.094 .083a1 1 0 0 0 1.226 0l.094 -.083l4 -4l.083 -.094a1 1 0 0 0 -.083 -1.32z" stroke-width="0" fill="currentColor" />
                                    </svg>Precio: $<?php echo $producto['precio_venta']?> 
                                </p>
                                <p>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-circle-check-filled" width="16" height="16" viewBox="0 0 24 24" stroke-width="1.5" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                    <path d="M17 3.34a10 10 0 1 1 -14.995 8.984l-.005 -.324l.005 -.324a10 10 0 0 1 14.995 -8.336zm-1.293 5.953a1 1 0 0 0 -1.32 -.083l-.094 .083l-3.293 3.292l-1.293 -1.292l-.094 -.083a1 1 0 0 0 -1.403 1.403l.083 .094l2 2l.094 .083a1 1 0 0 0 1.226 0l.094 -.083l4 -4l.083 -.094a1 1 0 0 0 -.083 -1.32z" stroke-width="0" fill="currentColor" />
                                    </svg>Productos disponibles: <?php echo $producto['stock'] ?> 
                                </p>
                                
                                <?php if (session()->perfil_id ==2): ?>
                                    <?php if($producto['stock'] > $producto['stock_min'] ):?>
                                        <a href="/carrito_agrega" class="btn btn-dark button-ordenarOnline">Agregar al carrito</a>
                                    <?php else : ?>
                                <p> <b>Agotado</b> </p> 
                                <?php endif;?>
                                 <?php else : ?>
                                
                              <?php 
                                    echo form_open('carrito_agrega');
                                    echo form_hidden ('id', $producto['id']);
                                    echo form_hidden ('precio_venta', $producto['precio_venta']);
                                    echo form_hidden ('nombre_producto', $producto['nombre_producto']);
                                ?>
                                <div class="d-grid gap-2"> 
                                    <?php 
                                    $btn = array(
                                        'class' => 'btn btn-dark button-ordenarOnline',
                                        'value' => 'Agregar al carrito',
                                        'name' => 'action'
                                    );
                                    echo form_submit($btn);
                                    echo form_close();
                                     ?>
                                </div>
                               
                            <?php endif ; ?>

                        </div>
                    </div>
                </div> 
                <?php endforeach;?>
                <?php endif ; ?>
         </div>
    </div>
      
    

