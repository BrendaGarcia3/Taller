<html> 
<br>
<div class="d-flex justify-content-center mt-3"  >
    <h1><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-confetti" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="#fd0061" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <path d="M4 5h2" />
  <path d="M5 4v2" />
  <path d="M11.5 4l-.5 2" />
  <path d="M18 5h2" />
  <path d="M19 4v2" />
  <path d="M15 9l-1 1" />
  <path d="M18 13l2 -.5" />
  <path d="M18 19h2" />
  <path d="M19 18v2" />
  <path d="M14 16.518l-6.518 -6.518l-4.39 9.58a1 1 0 0 0 1.329 1.329l9.579 -4.39z" />
</svg> ¡Felicidades por tu Compra!</h1>
</div> <br> <br>


<div class="container text-center">
    <div class="row align-items-start">
        <div class="col"> 
            <h4>Querido Cliente: </h4>
            <p>Desde el equipo -Verona- queremos expresar nuestro más sincero agradecimiento por haber elegido nuestros productos, gracias por haber 
            confiado en nosotros! Estamos comprometidos a ofrecerte productos/servicios de la más alta calidad y a brindarte una experiencia excepcional en cada paso del camino. 
            Tu compra no solo nos permite seguir creciendo como empresa, sino que también nos impulsa a continuar mejorando y ofreciendo lo mejor de nosotros mismos. 
            Esperamos que disfrutes al máximo tu compra!!
            </p> <br>
           

            <h5>Si desea volver al inicio toque en : </h5>
            <a class="btn btn-primary" href="<?php echo base_url('principal'); ?>">Volver a Inicio</a>
        </div>

    </div> 
</div> 
<br><br> <br>





<!-- FACTURA --> 
    <div class="container productos-destacados">
        <div class="row">
            <div class="col">
                <h2>Factura</h2>
                <hr>
                <p>Detalles de la venta:</p>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Producto</th>
                            <th>Numero de categoría</th>
                            <th>Cantidad</th>
                            <th>Precio Unitario</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ventas_detalle as $detalle) : ?>
                            <tr>
                                <td><?php echo $detalle['id']; ?></td>
                                <td>
                                    <?php
                                    $producto = $productoModel->find($detalle['producto_id']);
                                    echo $producto['nombre_producto'];
                                    ?>
                                </td>
                                <td><?php echo $detalle['categoria']; ?></td>
                                <td><?php echo $detalle['cantidad']; ?></td>
                                <td><?php echo $detalle['precio_venta']; ?></td>
                                <td><?php echo $detalle['cantidad'] * $detalle['precio_venta']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <hr>
                <p>Fecha de la venta: <?php echo date('Y-m-d H:i:s'); ?></p>
            </div>
        </div>
    </div>

</html> 
