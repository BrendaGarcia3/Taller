<div class="container mt-5 mb-5">
  <h2> Editar Producto </h2>
   <form method="post" id="user" name="user" action="<?= site_url('/Update2') ?>" enctype="multipart/form-data">
      <input type="hidden" name="id" id="id" value="<?php echo $producto['id']; ?>">
      <div class="form-group">
        <label>Nombre</label>
        <input type="text"  name="nombre_producto" class="form-control" value="<?php echo $producto['nombre_producto']; ?>">
      </div>
      <div class="form-group">
        <label>Categoria</label>
        <input type= 'int' name="categoria" class="form-control" value="<?php echo $producto['categoria']; ?>">
      </div>
      <div class="form-group">
        <label>Precio</label>
        <input type="text"  name="precio" class="form-control" value="<?php echo $producto['precio']; ?>">
      </div>
      <div class="form-group">
        <label>Precio venta</label>
        <input type="text"  name="precio_venta" class="form-control" value="<?php echo $producto['precio_venta']; ?>">
      </div>
      <div class="form-group">
        <label>Stock</label>
        <input type="int"  name="stock" class="form-control" value="<?php echo $producto['stock']; ?>">
      </div>
      <div class="form-group">
        <label>Stock Min</label>
        <input type="int"  name="stock_min" class="form-control" value="<?php echo $producto['stock_min']; ?>">
      </div> <br>
      <div class="form-group">
        <button type="submit" class="btn btn-dark btn-block">Guardar cambios</button>
        <button type="submit" class="btn btn-danger btn-block">Cancelar</button>
      </div>
    </form>
  </div>