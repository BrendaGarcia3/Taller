<html>
   <br><h2  class="crud">Lista de Productos</h2><br>
   <div class="container mt-4 ">
   <div class="mt-3 bg-white">
      <table class="table " id="productos" >
         <thead>
            <tr>
               <th>Id</th>
               <th>Nombre</th>
               <th>Imagen</th>
               <th>Categoría</th>
               <th>Precio</th>
               <th>Precio Venta</th>
               <th>Stock</th>
               <th>Stock Min</th>
            </tr>
         </thead>
         <tbody>
            <?php if($productos): ?>
            <?php foreach($productos as $producto): ?>
            <tr>
               <td><?php echo $producto['id']; ?></td>
               <td><?php echo $producto['nombre_producto']; ?></td>
               <td><img src="<?= base_url('assets/img/' . $producto['imagen']) ?>" alt="<?= $producto['nombre_producto'] ?>" style="width: 50px; height: auto;"></td>
               <td><?php echo $producto['categoria']; ?></td>
               <td><?php echo $producto['precio']; ?></td>
               <td><?php echo $producto['precio_venta']; ?></td>
               <td><?php echo $producto['stock']; ?></td>
               <td><?php echo $producto['stock_min']; ?></td>
               <td>

            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
         </tbody>
      </table>
   </div>

      <!-- Muestra los enlaces de paginacion --> 
      <div class="d-flex justify-content-center">
         <?php echo $pagination; ?>
      </div>
      
   </div>

</html>
<br> <br><br>