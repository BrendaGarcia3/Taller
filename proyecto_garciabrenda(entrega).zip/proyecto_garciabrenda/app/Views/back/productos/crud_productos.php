<?php

// Iniciar sesión solo si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Datos de conexión a la base de datos
$host = "localhost";
$user = "root";
$password = "";
$dbname = "antonella_garcia";

// Crear conexión
$cons = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
//if ($cons->connect_error) {
 //   die("Error de conexión: " . $cons->connect_error); }


// Inicializar variables
$query = "SELECT * FROM productos";
$params = [];
$mostrarBotonVolver = false; // Control para mostrar el botón de "Volver"

// Buscar si se envió el formulario
if (isset($_GET['enviar']) && !empty($_GET['busqueda'])) {
    $busqueda = $cons->real_escape_string($_GET['busqueda']);
    $query = "SELECT * FROM productos WHERE nombre_producto LIKE ?";
    $params[] = "%$busqueda%";
    $mostrarBotonVolver = true; // Activar el botón de "Volver"
}

// Preparar y ejecutar consulta
//almacena sentencia  $stmt
$stmt = $cons->prepare($query);
if (!empty($params)) {
    $stmt->bind_param("s", ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

?> 



<html> 
    <br><h2  class="crud">Crud de Productos</h2>
    <div class="container mt-4" >
         <div class="d-flex justify-content-end" >
             <a href="<?= site_url('/nuevo_producto') ?>" class="btn btn-primary mb-2">Agregar un producto</a>
         </div>
          
         <!-- Mostrar mensajes almacenados en la sesión -->
        <?php if (isset($_SESSION['msg'])): ?>
            <div class="alert alert-info">
                <?= $_SESSION['msg']; ?>
            </div>
        <?php endif; ?>

        <!-- Buscador -->
        <div class="container mt-4">
            <nav class="navbar bg-body-tertiary">
                <div class="container-fluid">
                    <form class="d-flex" role="search" method="get" action="">
                        <input class="form-control me-2" type="search" name="busqueda" placeholder="Buscar Producto" required>
                        <input class="btn btn-outline-success" type="submit" name="enviar" value="Buscar">
                    </form>
                </div>
            </nav>
        </div>
        
        <!-- Botón para volver a la tabla completa -->
        <?php if ($mostrarBotonVolver): ?>
            <div class="mt-3">
                <a href="crud_productos" class="btn btn-secondary">Volver</a>
            </div>
        <?php endif; ?>


        
        <!-- Tabla de productos-->
    <div class="mt-3 bg-white">
        <table class="table table-bordered" id="productos" enctype="multipart/form-data" >
            <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Imagen</th>
                        <th>Categoría</th>
                        <th>Precio</th>
                        <th>Precio Venta</th>
                        <th>Stock</th>
                        <th>Stock min</th>
                        <th>Editar</th>
                        <th>Estado</th>
                        
                    </tr>
            </thead>
                <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($producto = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $producto['id'] ?></td>
                            <td><?php echo $producto['nombre_producto'] ?></td>
                            <td><img src="<?= base_url('assets/img/' . $producto['imagen']) ?>" alt="<?= $producto['nombre_producto'] ?>" style="width: 50px; height: auto;"></td>
                            <td><?php echo $producto['categoria'] ?></td>
                            <td><?php echo $producto['precio'] ?></td>
                            <td><?php echo $producto['precio_venta'] ?></td>
                            <td><?php echo $producto['stock'] ?></td>
                            <td><?php echo $producto['stock_min'] ?></td>
                            <td> <a href="<?php echo base_url('edit_producto/'. $producto['id']) ?>" class="btn btn-dark btn-sm">Editar</a></td>
                            <td>
                                <form action="<?= base_url('deshabilitar/' . $producto['id']) ?>" method="POST">
                                    <input type="hidden" name="_method" value="PATCH">
                                    <button type="submit" class="btn btn-danger btn-sm">Deshabilitar</button>
                                </form>
                            </td>
                        </tr>
                       <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">No se encontraron productos</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
        </table>
    </div>
</div>
<br>
<br>
<br>
</html>

<?php
// Cerrar conexión
$cons->close();
?>

