<div class="container mt-5 mb-5">
  <h2> Nuevo Producto </h2>
    <form method="post"  enctype="multipart/form-data"  action="<?= site_url('/guardar_nuevoP') ?>">

        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" class="form-control" id="nombre" name="nombre_producto" required>
        </div>
        <div class="form-group">
            <label for="imagen">Imagen:</label>
            <input type="file" class="form-control-file" id="imagen" name="imagen" required>
        </div>
        <div class="form-group">
        <label for="categoria">Categoría:</label>
            <select class="form-control" id="categoria" name="categoria" required>
                <?php
                $categoriaModel = new \App\Models\categoria_model();
                $categorias = $categoriaModel->findAll();
                foreach ($categorias as $categoria) {
                    echo '<option value="' . $categoria['id'] . '">' . $categoria['descripcion'] . '</option>';
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="precio">Precio:</label>
            <input type="text" class="form-control" id="precio" name="precio" required>
        </div>
        <div class="form-group">
            <label for="precio_vta">Precio de venta:</label>
            <input type="text" class="form-control" id="precio_venta" name="precio_venta" required>
        </div>
        <div class="form-group">
            <label for="stock">Stock:</label>
            <input type="text" class="form-control" id="stock" name="stock" required>
        </div>
        <div class="form-group">
            <label for="stock_min">Stock mínimo:</label>
            <input type="text" class="form-control" id="stock_min" name="stock_min" required>
        </div>
        <div class="form-group">
            <label for="baja">Eliminado:</label>
            <select class="form-control" id="baja" name="baja" required>
                <option value="SI">Sí</option>
                <option value="NO">No</option>
            </select>
        </div> <br>
        <button type="submit" class="btn btn-dark btn-block">Guardar cambios</button>
    </form>
</div>


