<?php
// Iniciar sesión solo si no está activa
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Datos de conexión a la base de datos
$host = "localhost";
$user = "root";
$password = "";
$dbname = "antonella_garcia";

// Crear conexión
$cons = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
//if ($cons->connect_error) {
 //   die("Error de conexión: " . $cons->connect_error); }

// Inicializar variables
$query = "SELECT * FROM usuarios";
$params = [];
$mostrarBotonVolver = false; // Control para mostrar el botón de "Volver"

// Buscar si se envió el formulario
if (isset($_GET['enviar']) && !empty($_GET['busqueda'])) {
    $busqueda = $cons->real_escape_string($_GET['busqueda']);
    $query = "SELECT * FROM usuarios WHERE nombre LIKE ?";
    $params[] = "%$busqueda%";
    $mostrarBotonVolver = true; // Activar el botón de "Volver"
}

// Preparar y ejecutar consulta
//almacena sentencia  $stmt
$stmt = $cons->prepare($query);
if (!empty($params)) {
    $stmt->bind_param("s", ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<html>
    <br>
    <h2 class="crud">Crud de Usuarios</h2>
    <div class="container mt-4">
        <div class="d-flex justify-content-end">
            <a href="<?= site_url('/registro') ?>" class="btn btn-primary mb-2">Agregar un usuario</a>
        </div>

        <!-- Mostrar mensajes almacenados en la sesión -->
        <?php if (isset($_SESSION['msg'])): ?>
            <div class="alert alert-info">
                <?= $_SESSION['msg']; ?>
            </div>
        <?php endif; ?>

        <!-- Buscador -->
        <div class="container mt-4">
            <nav class="navbar bg-body-tertiary">
                <div class="container-fluid">
                    <form class="d-flex" role="search" method="get" action="">
                        <input class="form-control me-2" type="search" name="busqueda" placeholder="Buscar Usuario" required>
                        <input class="btn btn-outline-success" type="submit" name="enviar" value="Buscar">
                    </form>
                </div>
            </nav>
        </div>

        <!-- Botón para volver a la tabla completa -->
        <?php if ($mostrarBotonVolver): ?>
            <div class="mt-3">
                <a href="crud_usuario" class="btn btn-secondary">Volver</a>
            </div>
        <?php endif; ?>

        <!-- Tabla de usuarios -->
        <div class="mt-3 bg-white">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Editar</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($user = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $user['id']; ?></td>
                                <td><?= $user['nombre']; ?></td>
                                <td><?= $user['apellido']; ?></td>
                                <td><?= $user['email']; ?></td>
                                <td>
                                    <a href="<?= base_url('edit_usuario/' . $user['id']); ?>" class="btn btn-primary btn-sm">Editar</a>
                                </td>
                                <td>
                                    <?php if ($user['baja'] != "0"): ?>
                                        <button class="btn btn-danger btn-sm">Inactivo</button>
                                    <?php else: ?>
                                        <button class="btn btn-success btn-sm">Activo</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">No se encontraron usuarios</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</html>

<?php
// Cerrar conexión
$cons->close();
?>
