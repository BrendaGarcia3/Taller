<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="<?= base_url("assets/css/bootstrap.min.css"); ?>"> 
    <link rel="stylesheet" href="<?= base_url("assets/css/style.css"); ?>" > 

    <title>Mi Perfil</title>
</head>
<body>

    <!-- Incluir el Header con la barra de navegación -->
    <?php include('header.php'); ?>  

    <div class="container mt-4">
        <h2 class="mt-3 text-center">MI PERFIL</h2>

        <div class="card p-4">
            <h2>Perfil de Usuario</h2>
            <p><strong>Nombre:</strong> <?= esc($nombre); ?></p>
            <p><strong>Correo:</strong> <?= esc($email); ?></p>
            <p><strong>Usuario:</strong> <?= esc($usuario); ?></p>
            <p><strong>Rol:</strong> <span class="<?= esc($perfil_id); ?>"><?= ucfirst(esc($perfil_id)); ?></span></p>

            <?php if (session()->get('perfil_id') == 1): ?> 
                <h3>Opciones de Administrador</h3>
                <p>🔹 Gestionar usuarios</p>
                <p>🔹 Configuración avanzada</p>
            <?php else: ?>
                <h3>Opciones de Cliente</h3>
                <p>🔹 Ver productos</p>
                <p>🔹 Hacer compras</p>
            <?php endif; ?>
        </div>
    </div> 

    <!-- Incluir el Footer -->
    <?php include('footer.php'); ?>  

</body>
</html>
