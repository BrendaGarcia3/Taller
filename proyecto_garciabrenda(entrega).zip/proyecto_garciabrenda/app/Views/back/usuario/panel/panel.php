<?php
    $session = session();
?>

<?php if(session()->get('perfil_id') == 1 ): ?>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
            <a class="nav-link active" aria-current="page" href="<?php echo base_url('perfil'); ?>"> 
                <button type="submit" class="btn btn-primary">
                       <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user" width="20" height="20" viewBox="0 0 24 24" stroke-width="1" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round">
                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                          <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0" />
                          <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                       </svg> Administrador: <?php echo session('nombre'); ?>  
                </button >
              </a>
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo base_url('principal'); ?>">Inicio</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"   aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
         <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo base_url('crud_usuario'); ?>">CRUD Usuarios</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('crud_productos'); ?>" >CRUD Productos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('lista_producto'); ?>" >Listar</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('logout'); ?>">Cerrar sesión</a> 
            </li>
         </ul>
      </div>
    </div>
  </nav>


<?php   else: ?>
<!-- barra de nav para clientes --> 

<nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="btn btn-info active btnUser btn-sm">
                    <a > <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user" width="20" height="20" viewBox="0 0 24 24" stroke-width="1" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                      <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0" />
                      <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                    </svg>CLIENTE: <?php echo session('nombre'); ?>   </a> 
                </div>
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo base_url('principal'); ?>">Inicio</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"   aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
         <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('catalogo2'); ?>" >Catalogo</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('Carrito'); ?>" >Mis compras</a>
                <!--<i class="fa fa-shopping-cart"></i> -->
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('logout'); ?>">Cerrar sesión</a>
            </li>
         </ul>
      </div>
    </div>
  </nav>
<?php endif; ?>