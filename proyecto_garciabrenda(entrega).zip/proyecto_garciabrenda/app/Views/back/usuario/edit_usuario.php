<div class="container mt-5 mb-5">
  <h2> Modificar Usuario </h2>
    <form method="post" id="user" name="user" action="<?= site_url('/update') ?>">
      <input type="hidden" name="id" id="id" value="<?php echo $user['id']; ?>">
      <div class="form-group">
        <label>Nombre</label>
        <input type="text" name="nombre" class="form-control" value="<?php echo $user['nombre']; ?>">
      </div>
      <div class="form-group">
        <label>Apellido</label>
        <input type="text" name="apellido" class="form-control" value="<?php echo $user['apellido']; ?>">
      </div>
      <div class="form-group">
        <label>Nombre de usuario</label>
        <input type="text" name="usuario" class="form-control" value="<?php echo $user['usuario']; ?>">
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="email"  name="email" class="form-control" value="<?php echo $user['email']; ?>">
      </div> <br> <br>
      <div class="form-group">
        <button type="submit" class="btn btn-dark btn-block">Guardar cambios</button>
        <button type="submit" class="btn btn-danger btn-block">Cancelar</button>
      </div>
    </form>
  </div>


