<?php
namespace App\Models;
use CodeIgniter\Model; 


class categoria_model extends Model {
    protected $table = 'categoria'; 
    protected $primaryKey = 'id'; 
    protected $allowedFields = ['descripcion', 'archivo']; 

    public function getCategoria(){
        return $this->findAll();
    }
}